# ray-MVVM
Understanding MVVM Design Patterns using https://www.raywenderlich.com/8984-mvvm-on-android.
